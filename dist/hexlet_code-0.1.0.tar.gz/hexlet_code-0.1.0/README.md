### Hexlet tests and linter status:
[![Actions Status](https://github.com/DariaChadina/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DariaChadina/python-project-49/actions)

###CodeClimate
[![Maintainability](https://api.codeclimate.com/v1/badges/975bf847bce2e1faa890/maintainability)](https://codeclimate.com/github/DariaChadina/python-project-49/maintainability)

###Asciinema(brain-even)
https://asciinema.org/connect/6a6e1707-e135-4286-8a06-ad19a7c6d1af

###Asciinema(brain-calc)
https://asciinema.org/a/uXxL18jIS2ZOHbWt6CyNvaY7D

###Asciinema(brain-gcd)
https://asciinema.org/a/zwzkmroS4PLaVxR6xXJziqoEj
