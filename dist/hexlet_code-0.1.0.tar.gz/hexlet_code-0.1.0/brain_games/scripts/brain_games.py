#!/Users/daria_chadina/Library/Python/3.11/bin  python3

def main():
	print("Welcome to the Brain Games!")

if __name__ == '__main__':
	main()

