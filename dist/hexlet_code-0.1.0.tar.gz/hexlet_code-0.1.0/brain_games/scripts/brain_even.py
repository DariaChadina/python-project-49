#!/usr/bin/env python3

from brain_games.games.even_game import main as func_game


def main():
    func_game()


if __name__ == '__main__':
    main()
